from __future__ import annotations

import time
from typing import Any, Dict, Tuple

from fastapi import APIRouter, HTTPException, Query
from instagrapi.exceptions import (
    ChallengeRequired,
    LoginRequired,
    PleaseWaitFewMinutes,
    TwoFactorRequired,
)

from ..services.ig_client import get_ig_client, get_ig_lock

router = APIRouter(prefix="/api/users", tags=["users-posts"])

CACHE_TTL_SECONDS = 90
_cache: Dict[str, Tuple[float, Dict[str, Any]]] = {}


@router.get("/posts")
def get_user_posts(
    username: str = Query(min_length=1, max_length=30),
    limit: int = Query(default=12, ge=1, le=24),
    skip: int = Query(default=0, ge=0),
) -> Dict[str, Any]:
    cache_key = f"{username}:{skip}:{limit}"
    cached = _cache.get(cache_key)
    now = time.time()
    if cached and now - cached[0] < CACHE_TTL_SECONDS:
        return cached[1]

    ig_lock = get_ig_lock()
    try:
        with ig_lock:
            cl = get_ig_client()
            user_id = cl.user_id_from_username(username)
            try:
                medias = cl.user_medias_v1(user_id, amount=skip + limit)
            except Exception:
                medias = cl.user_medias(user_id, amount=skip + limit)

    except LoginRequired:
        raise HTTPException(401, "IG_LOGIN_REQUIRED")
    except TwoFactorRequired:
        raise HTTPException(401, "IG_TWO_FACTOR_REQUIRED")
    except ChallengeRequired:
        raise HTTPException(403, "IG_CHALLENGE_REQUIRED")
    except PleaseWaitFewMinutes:
        raise HTTPException(429, "IG_RATE_LIMITED")
    except Exception:
        raise HTTPException(502, "IG_FETCH_FAILED")

    posts = []
    for media in medias[skip : skip + limit]:
        shortcode = getattr(media, "code", None)
        product_type = getattr(media, "product_type", None)
        link_instagram = ""
        if shortcode:
            if product_type == "clips":
                link_instagram = f"https://www.instagram.com/reel/{shortcode}/"
            else:
                link_instagram = f"https://www.instagram.com/p/{shortcode}/"

        thumbnail = getattr(media, "thumbnail_url", None) or getattr(media, "url", None) or ""
        taken_at = getattr(media, "taken_at", None)

        posts.append(
            {
                "id": str(getattr(media, "id", "")),
                "thumbnail": thumbnail,
                "shortcode": shortcode or "",
                "link_instagram": link_instagram,
                "caption": getattr(media, "caption_text", None),
                "taken_at": taken_at.isoformat() if taken_at else None,
            }
        )

    payload = {
        "posts": posts,
        "total": len(posts),
        "skip": skip,
        "limit": limit,
    }
    _cache[cache_key] = (now, payload)
    return payload
